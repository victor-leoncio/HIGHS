# Mistura de Petróleo

import highspy

h = highspy.Highs()

xA1 = h.addVariable(lb = 0, ub = h.inf)
xA2 = h.addVariable(lb = 0, ub = h.inf)
xA3 = h.addVariable(lb = 0, ub = h.inf)
xA4 = h.addVariable(lb = 0, ub = h.inf)

xZ1 = h.addVariable(lb = 0, ub = h.inf)
xZ2 = h.addVariable(lb = 0, ub = h.inf)
xZ3 = h.addVariable(lb = 0, ub = h.inf)
xZ4 = h.addVariable(lb = 0, ub = h.inf)

xS1 = h.addVariable(lb = 0, ub = h.inf)
xS2 = h.addVariable(lb = 0, ub = h.inf)
xS3 = h.addVariable(lb = 0, ub = h.inf)
xS4 = h.addVariable(lb = 0, ub = h.inf)

h.addConstr( xA1 + xZ1 + xS1 <= 3500 )
h.addConstr( xA2 + xZ2 + xS2 <= 2200 )
h.addConstr( xA3 + xZ3 + xS3 <= 4200 )
h.addConstr( xA4 + xZ4 + xS4 <= 1800 )

h.addConstr( xS1 <= 0.3 * (xS1 + xS2 + xS3 + xS4) )
h.addConstr( xS2 >= 0.4 * (xS1 + xS2 + xS3 + xS4) )
h.addConstr( xS3 <= 0.5 * (xS1 + xS2 + xS3 + xS4) )

h.addConstr( xZ1 <= 0.3 * (xZ1 + xZ2 + xZ3 + xZ4) )
h.addConstr( xZ1 >= 0.1 * (xZ1 + xZ2 + xZ3 + xZ4) )

h.addConstr( xA1 <= 0.7 * (xA1 + xA2 + xA3 + xA4) )

h.maximize(  
      22 * (xA1 + xA2 + xA3+ xA4 ) \
    + 28 * (xZ1 + xZ2 + xZ3+ xZ4 ) \
    + 35 * (xS1 + xS2 + xS3+ xS4 ) \
    - 19 * (xA1 + xZ1 + xS1) \
    - 24 * (xA2 + xZ2 + xS2) \
    - 20 * (xA3 + xZ3 + xS3) \
    - 27 * (xA4 + xZ4 + xS4)\
)

print()
status = h.writeModel('example_2.lp')
print('writeModel(\'example_2.lp\') status =', status)
print()

h.run()

print()


solution = h.getSolution()
basis = h.getBasis()
info = h.getInfo()
model_status = h.getModelStatus()

print('Model status = ', h.modelStatusToString(model_status))
print('[xA1, xA2, xA3, xA4] = ', solution.col_value[:4])
print('[xZ1, xZ2, xZ3, xZ4] = ', solution.col_value[4:8])
print('[xS1, xS2, xS3, xS4] =  ', solution.col_value[8:])
print('Optimal objective (Z) = ', info.objective_function_value)
print('Iteration count = ', info.simplex_iteration_count)
print('Primal solution status = ', h.solutionStatusToString(info.primal_solution_status))
print('Dual solution status = ', h.solutionStatusToString(info.dual_solution_status))
print('Basis validity = ', h.basisValidityToString(info.basis_validity))
