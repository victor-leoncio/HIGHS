# Window Glass

import highspy

h = highspy.Highs()

x1 = h.addVariable(lb = 0, ub = h.inf)
x2 = h.addVariable(lb = 0, ub = h.inf)

h.addConstr(x1 <= 4)
h.addConstr(2*x2 <= 12)
h.addConstr(3*x1 + 2*x2 <= 18)

h.maximize(3*x1 + 5*x2)

print()
status = h.writeModel('example_0.lp')
print('writeModel(\'example_0.lp\') status =', status)
print()

h.run()
print()

solution = h.getSolution()
basis = h.getBasis()
info = h.getInfo()
model_status = h.getModelStatus()

print('Model status = ', h.modelStatusToString(model_status))
print('[x1, x2]  = ',   solution.col_value)
print('Optimal objective (Z) = ', info.objective_function_value)
print('Optimal objective (Z) adjust (x1000) = ', info.objective_function_value * 1000)
print('Iteration count = ', info.simplex_iteration_count)
print('Primal solution status = ', h.solutionStatusToString(info.primal_solution_status))
print('Dual solution status = ', h.solutionStatusToString(info.dual_solution_status))
print('Basis validity = ', h.basisValidityToString(info.basis_validity))
