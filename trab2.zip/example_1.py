# Dieta

import highspy

h = highspy.Highs()

x1 = h.addVariable(lb = 0, ub = h.inf)
x2 = h.addVariable(lb = 0, ub = h.inf)
x3 = h.addVariable(lb = 0, ub = h.inf)
x4 = h.addVariable(lb = 0, ub = h.inf)

h.addConstr( 2*x1 + 2*x2 + 10*x3 + 20*x4 >= 11 )
h.addConstr( 50*x1 + 20*x2 + 10*x3 + 30*x4 >= 70 )
h.addConstr( 80*x1 + 70*x2 + 10*x3 + 80*x4 >= 250 )

h.minimize( 2*x1 + 4*x2 + 1.5*x3 + x4 )

print()
status = h.writeModel('example_1.lp')
print('writeModel(\'example_1.lp\') status =', status)
print()

h.run()

print()


solution = h.getSolution()
basis = h.getBasis()
info = h.getInfo()
model_status = h.getModelStatus()

print('Model status = ', h.modelStatusToString(model_status))
print('[x1, x2, x3, x4]  = ', solution.col_value)
print('Optimal objective (Z) = ', info.objective_function_value)
print('Iteration count = ', info.simplex_iteration_count)
print('Primal solution status = ', h.solutionStatusToString(info.primal_solution_status))
print('Dual solution status = ', h.solutionStatusToString(info.dual_solution_status))
print('Basis validity = ', h.basisValidityToString(info.basis_validity))
